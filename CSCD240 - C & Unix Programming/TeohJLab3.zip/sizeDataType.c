#include <stdio.h>

int sizeOfShort = sizeof(short);
int sizeOfInt = sizeof(int);
int sizeOfLong = sizeof(long);
int sizeOfDouble = sizeof(double);


int main(){

	printf("Size of datatype short is %d \n", sizeOfShort);
	printf("Size of datatype int is %d \n", sizeOfInt);
	printf("Size of datatype Long is %d \n", sizeOfLong);
	printf("Size of datatype double is %d \n", sizeOfDouble);
return 0;
}
