To Compile:
javac *.java

To run server:
java WorkDistributor

To run non-gui tests:
java TesterClient


To run gui
java ParallelClient