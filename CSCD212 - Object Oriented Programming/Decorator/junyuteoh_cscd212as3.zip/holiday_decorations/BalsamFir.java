package holiday_decorations;

public class BalsamFir extends Tree{

	public BalsamFir() {
		this.name = "Balsam Fir";
	}

	@Override
	public double Cost() {
		// TODO Auto-generated method stub
		return 25;
	}

}
