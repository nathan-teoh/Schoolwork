package holiday_decorations;

public class FraserFir extends Tree{
	
	public FraserFir() {
		this.name = "Fraser Fir";
	}

	@Override
	public double Cost() {
		return 35;
	}
	


}
