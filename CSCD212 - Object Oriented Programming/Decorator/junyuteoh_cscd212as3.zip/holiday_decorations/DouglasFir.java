package holiday_decorations;

public class DouglasFir extends Tree{
	public DouglasFir() {
		this.name = "Douglas Fir";
	}

	@Override
	public double Cost() {
		// TODO Auto-generated method stub
		return 30;
	}


}
