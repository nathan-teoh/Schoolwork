package holiday_decorations;

public class ColoradoBlueSpruce extends Tree{

	public ColoradoBlueSpruce() {
		this.name = "Colorado Blue Spruce";
	}

	@Override
	public double Cost() {
		// TODO Auto-generated method stub
		return 50;
	}
	
	

}
